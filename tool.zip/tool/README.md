# WP-File-Manager Unrestricted File Upload Vulnerability!
## Python2
## Coder is not responsible for any illegal usage!
## CVE   : CVE-2020-25213
## Date  : 11-09-2020
## Usage : python exploit.py
## ICQ   : @the.seller
